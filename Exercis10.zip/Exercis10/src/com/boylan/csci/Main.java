package com.boylan.csci;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Spliterator;
import java.util.function.Consumer;

class Contact { //contact class that contains name and email
    private String name;
    private String email;

    Contact(String name, String email){
        this.name = name;
        this.email = email;
    }

    public void displayInfo(){
        System.out.println("Name: " + name + "\nEmail: " + email);
    }
}

class ContactCollection implements Iterable<Contact> { //collection class that implements iterable interface

    private List<Contact> collection = new ArrayList();

    public ContactCollection() {

    }

    public void add(Contact con) {
        collection.add(con);
    }

    @Override
    public Iterator<Contact> iterator() {
        return collection.listIterator();
    }

    @Override
    public void forEach(Consumer<? super Contact> action) {
    }

    @Override
    public Spliterator<Contact> spliterator() {
        return null;
    }
}
public class Main {

    public static void main(String[] args) {
        Contact uno = new Contact("The Joker","tjokar@twinsdail.org");
        Contact dos = new Contact("Silvia Joker", "sjoker@gekkokanhigh.com");
        Contact tres =new Contact ("Mitsuru Kirijo","snowqueen@kirijo.org");
        ContactCollection contacta = new ContactCollection();
        contacta.add(uno);
        contacta.add(dos);
        contacta.add(tres);


        for(Contact con: contacta){ //display all contacts in collection class.
            con.displayInfo();
        }
    }

}

